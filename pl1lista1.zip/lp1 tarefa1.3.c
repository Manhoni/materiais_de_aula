#include <stdio.h>
#include <conio.h>
#include <windows.h>

// tarefa 1.3

main () {
	int i;
	
	for (i=1; i<=50; i++){
		printf("\n %d",i);
	}
	
}

