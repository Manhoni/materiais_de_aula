#include <stdio.h>
#include <conio.h>
#include <windows.h>

// tarefa 2.3

main () {
	int i;
	
	for(i=1;i<38;i++){
		if (i % 2 == 0){
			printf("\n%d", i);
		}
	}
}

